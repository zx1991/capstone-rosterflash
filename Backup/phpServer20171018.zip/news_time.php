<?php 
echo "<p>&nbsp;&nbsp;&nbsp;&nbsp;时间：".date('H : i : s')."</p>";
?>
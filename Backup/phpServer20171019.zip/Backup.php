<?php
	include_once 'header.php';
?>


<section class="main-container">
	<div class="main-wrapper">
		<h2></h2>
		<?php
			if (isset($_SESSION['u_id'])) {
				
			}
		?>
	</div>
    
   <?php
	include_once 'news.php';
?>
    
</section>



<?php

    
    include 'includes/dbh.inc.php';

    $sql = "SELECT * FROM courses WHERE user_name= '".$_SESSION['u_id']."'";
    $myresult = mysqli_query($conn, $sql);
    $courseInfo = array();
    while ($row_user = mysqli_fetch_assoc($myresult)){
        $userInfo[]=$row_user;
    }
    
?>

<select name="per1" id="per1" onchange="showChart(this.value)">
  <option onchange="showChart(this.value)">Courses</option>
  <?php
    foreach($userInfo as $user) { ?>
      <option value="<?= $user['course_id'] ?>"><?= $user['course_name'] ?></option>
  <?php
    } ?>
</select> 

<canvas id="myChart" ></canvas>
  
	
<div id="txtHint"></div>

<script type="text/javascript">
    var NumberofAttendance = 0;
    var NumberofAbsence = 0;
    
    
   var ctx ;
    var myChart;
    var config;
    
    window.onload = function() {
        
       
        ctx = document.getElementById("myChart").getContext('2d');
        
        
        
                    
                                          
                                          config = {
  type: 'pie',
  data: {
    labels: ["Attendance", "Absence"],
    datasets: [{
      backgroundColor: [
        "#2ecc71",
        "#3498db",
        
      ],
      data: [NumberofAttendance, NumberofAbsence]
    }]
  }
};
   myChart = new Chart(ctx, config);
    };
    
   
    
 function showChart(str) {
     
	if (str == "") {
        
        return;} 
     else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var response = this.responseText;
               
                var Numberlist = response.split(',');    
                NumberofAttendance = parseInt(Numberlist[0]);
                NumberofAbsence = parseInt(Numberlist[1]);
                myChart.data.datasets[0].data[0] = NumberofAttendance;
                 myChart.data.datasets[0].data[1] = NumberofAbsence;
                myChart.update();
                
  
            }
        }
        xmlhttp.open("GET", "getTotalNumber.php?q="+str,true);
        xmlhttp.send();
         
        
}
};
    

	</script>
	


<?php
	include_once 'footer.php';
?>
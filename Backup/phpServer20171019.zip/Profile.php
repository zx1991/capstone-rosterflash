<?php
	include_once 'header.php';
?>


<section class="main-container">
	<div class="main-wrapper">
		<h2></h2>
        
        <?php
	include_once 'TopNavigation.php';
?>
		<?php
			if (isset($_SESSION['u_id'])) {
				
			}
        
        ?>
	</div>
</section>


<div class="main">
    
    <hr>
    <hr>
    <?php
        echo '
        <p style="font-size:36px;color:blue;">Dear '.$_SESSION['u_id'].':</p>
        '
    ?>
</div>
<?php
	include_once 'footer.php';
?>:

<div id="mySideNav" class="sidenav">
  
  <a href="info.php" id="RateLink">Total Ratio</a>
  <a href="ReportBydate.php" id="DateLink">Daily record</a>
  <a href="StudentTable.php" id="TableLink">Detailed Table</a>
</div>


<?php
	include_once 'header.php';
?>

<section class="main-container">
	<div class="main-wrapper">
		<h2></h2>
        
        <?php
	include_once 'TopNavigation.php';
?>
		<?php
			if (isset($_SESSION['u_id'])) {
				
			}
        ?>
	</div>
    
</section>


 <?php include_once 'SideNavigation.php';
?>


<div class="main">

<?php

    
    include 'includes/dbh.inc.php';

    $sql = "SELECT * FROM courses WHERE user_name= '".$_SESSION['u_id']."'";
    $myresult = mysqli_query($conn, $sql);
    $courseInfo = array();
    while ($row_user = mysqli_fetch_assoc($myresult)){
        $userInfo[]=$row_user;
    }
    
?>

<select name="per1" id="per1" onchange="showTable(this.value)">
  <option value='Null'>Courses</option>
  <?php
    foreach($userInfo as $user) { ?>
      <option value="<?= $user['course_id'] ?>"><?= $user['course_name'] ?></option>
  <?php
    } ?>
</select> 

<table id="attendances" border="2">
</table>

<?php
    
    if(isset($_GET['q'])){
    $q = $_GET['q'];
    }else{
        
        $q = '';
    }
?>
    
<script type="text/javascript">
    var NumberofAttendance = 0;
    var NumberofAbsence = 0;
    
      
   document.getElementById('per1').selectedIndex = parseInt("<?php echo $q; ?>");
    
    
    showTable(document.getElementById('per1').options[parseInt("<?php echo $q; ?>")].value);
    
 function showTable(str) {
     
     
     var link = document.getElementById('per1');
     var value = link.selectedIndex;
     
     document.getElementById('RateLink').setAttribute('href', "info.php?q="+ value);
     document.getElementById('DateLink').setAttribute('href', "ReportBydate.php?q="+ value);
     document.getElementById('TableLink').setAttribute('href', "StudentTable.php?q="+ value);
      
    
	if (str == "") {
        
        return;} 
     else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var response = this.responseText;
              
                parseAttendances(response);
                
              
               
                
  
            }
        }
        
        var url="getStudentList.php";
        xmlhttp.open("GET", url+ "?q="+str,true);
        xmlhttp.send();
         
        
}
};
    
    function parseAttendances(attendances_str){
	var attendances = JSON.parse(attendances_str);
	var dateArray = new Array();
	var students = trimAttendances(attendances, dateArray);
	var table = document.getElementById("attendances");
        
	if(students == 0){
		table.innerHTML = "";
		return;
	}else{
		// refresh
		table.innerHTML = "";
		// table header
		var th = "<tr><th>Last Name</th>"+
				 "<th>First Name</th>"+
				 "<th>ID</th>"+
                 "<th>Total Absence</th>"+
                 "<th>Total Attentance</th>";
        
		for(var i=0; i<dateArray.length; i++){
			th += "<th>"+dateArray[i]+"</th>";
		}
		table.innerHTML += th+"</tr>";
		//table body
		for(var i=0; i<students.length; i++){
			var student = students[i];
            if(student.noa >2){
            var tr = "<tr ><td align='center'>"+student.last_name+"</td>"+
					 "<td align='center'>"+student.first_name+"</td>"+
					 "<td align='center'>"+student.student_id+"</td>"+
					 "<td bgcolor='red' align='center'>"+student.noa+"</td>"+
					 "<td align='center'>"+student.noat+"</td>";
            }else{
			var tr = "<tr><td align='center'>"+student.last_name+"</td>"+
					 "<td align='center'>"+student.first_name+"</td>"+
					 "<td align='center'>"+student.student_id+"</td>"+
					 "<td align='center'>"+student.noa+"</td>"+
					 "<td align='center'>"+student.noat+"</td>";
            }
			for(var j=0; j<dateArray.length; j++){
				var date = dateArray[j];
				if(student[date]){
					tr += "<td align='center'>"+student[date]+"</td>";
				}else{
					tr += "<td align='center'>&nbsp;</td>";
				}
			}
			tr += "</tr>";
			table.innerHTML += tr;
		}
	}
}
    
    function trimAttendances(attendances, dateArray){
	var numOfDates = 0;
        
	if(attendances.length == 0){
        
		return 0;
	}else{
        
		var id = attendances[0].student_id;
		dateArray[0] = attendances[0].date;
		for(var i=1; i<attendances.length; i++){
			if(attendances[i].student_id !== id){
				break;
			}else{
				dateArray[i] = attendances[i].date;
			}
		}
		numOfDates = i;
	}
        
	var students = new Array();
	var counter = 0;
	for(var i=0; i<attendances.length; i+=numOfDates){
		var student = {};
        var absencecount = 0;
        var attendancecount =0;
		student.last_name = attendances[i].last_name;
		student.first_name = attendances[i].first_name;
		student.student_id = attendances[i].student_id;
		for(var j=0; j<numOfDates; j++){
			var date = dateArray[j];
			if(attendances[i+j].attendance === "1"){
				var time = attendances[i+j].time.substr(0,5);
				student[date] = time;
                attendancecount++;
                
			}else{
                absencecount++;
				student[date] = 0;
			}
		}
        
        student.noa = absencecount;
        student.noat = attendancecount;
       
		students[counter++] = student;
        
	}
        
	return students;
}

    

</script>
	
</div>

<?php
	include_once 'footer.php';
?>

<div id="myTopNav" class="topnav">
  <a href="Profile.php" id="profileLink">Profile</a>
  <a href="#" id="coursemLink">Manage Courses</a>
  <a href="info.php" id="AttendanceLink">Attendance</a>
  <a href="#" id=""></a>
</div>
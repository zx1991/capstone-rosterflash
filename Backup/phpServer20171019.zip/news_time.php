<?php 
    echo "<p>&nbsp;&nbsp;&nbsp;&nbsp;Time：".date('H : i : s')."</p>";
?>
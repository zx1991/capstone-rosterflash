<?php
	session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/normalize.css" type="text/css">
    
    <script src="js/Chart.min.js"></script>
    <!-- http://www.layui.com/doc -->
    <script src="./layui/layui.js"></script>
    <link rel="stylesheet" href="./layui/css/layui.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/login.css" type="text/css">
</head>
<body>
    <header class="site-header">
        <div class="site-header-inner container">
            <div class="site-logo">ROSTER TRACKER</div>
        </div>
    </header>

    <div class="site-main">
        <div class="site-main-inner">
            <div class="login-container">
                <div class="layui-tab layui-tab-card">
                    <ul class="layui-tab-title">
                        <li class="layui-this">I am a teacher</li>
                        <li>I am a student</li>
                    </ul>
                    <div class="layui-tab-content">
                        <div class="layui-tab-item layui-show">
                            <div class='login'>
                                <form method='post' action="includes/login.inc.php" >
                                    <input type='text' placeholder='User' name='uid' required/>
                                    <input type='password' placeholder='Password' name='pwd' required/>
                                    <!-- put the error message here -->
                                    <div class="error_log"></div>
                                    <input type='submit' name="submit" value='Log in' />
                                </form>
                            </div>
                        </div>
                        <div class="layui-tab-item">
                            <div class='login'>
                                <form method='post' action="includes/student.login.inc.php">
                                    <input type='text' placeholder='Student ID' name='studentId' required/>
                                    <input type='text' placeholder='First Name' name='firstName' required/>
                                    <input type='text' placeholder='Last Name' name='lastName' required/>
                                    <!-- put the error message here -->
                                    <div class="error_log"></div>
                                    <input type='submit' name="submit" value='Check' />
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="site-footer">
        <div class="site-footer-inner container">
            <a href="pages/teacher/attendance/TotalRatio.php">test</a>
        </div>
    </footer>

    <script>
        layui.use('element', function(){
            var element = layui.element;
            // Some listener here
            element.on('tab(demo)', function(data){
//            console.log(data);
            });
        });
    </script>
</body>
</html>
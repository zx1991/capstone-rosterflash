<?php
	session_start();
    if (!isset($_SESSION['u_id'])) {
        
        header("Location: ../../../index.php");
			exit();	
    }
?>

<html>
<head>
    <title>Student Roster Tracker</title>
    <link rel="stylesheet" href="../../../css/normalize.css" type="text/css">
    <link rel="stylesheet" href="../../../css/style.css" type="text/css">
    <script src="../../../js/Chart.min.js"></script>
    
</head>

<body>
        <header class="site-header">
            <div class="container site-header-inner">
                <!-- logo -->
                <div class="site-logo">ROSTER TRACKER</div>
                <!-- navigation bar -->
                <nav class="nav site-menu">
                    <a href="profile.php" class="nav-link present" id="profileLink">Profile</a>
                    <a href="" class="nav-link" id="coursemLink">Manage Courses</a>
                    <a href="attendance/TotalRatio.php" class="nav-link" id="AttendanceLink">Attendance</a>
                    <!--<a href="#" id=""></a>-->
                </nav>

                <div class="logout">
                    <a href="../../../includes/logout.inc.php" id="logOut">Log out</a>
                </div>
            </div>
        </header>
    
    <div class="site-main">
            <div class="container site-main-inner">
                <div class="sidebar">
                    
                    
                </div>
                <!-- Content shows here -->
                <div class="content">
                    <div class="content-inner">
                        <canvas id="myChart" ></canvas>
                    </div>
                </div>
            </div>
        </div>

    
    
    
    <footer class="site-footer">
            <div class="container site-footer-inner">

            </div>
        </footer>
</body>
</html>
(function() {

  document.writeln('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>'); /*==== JQUERY LIB ====*/
  
  document.writeln('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>'); /*==== JQUERY UI PLUGINS ====*/
   document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.dataTables.js"></script>'); /*==== DATA TABLE ====*/
  document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/custom.js"></script>'); /*==== ALL FUNCTIONS ====*/
  
  document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/html5shiv-printshiv.js"></script>'); /*==== HTML5 ====*/
  
  document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.fullcalendar.js"></script>'); /*==== FULL CALENDER ====*/
  
 
  
  document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.sortable.js"></script>'); /*==== DATA TABLE SHORTABLE ====*/
  
  document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.resizable.js"></script>'); /*==== DATA TABLE RESIZABLE ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/autogrowtextarea.js"></script>'); /*==== AUTOGROW TEXTAREA ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.autotab.js"></script>'); /*==== AUTOTABS INPUT FIELDS ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.wysiwyg.js"></script>'); /*==== WYSIWYG INPUT FIELDS ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery-barcode-2.0.2.min.js"></script>'); ==== QR AND BAR CODE GENERATOR ====
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.msgbox.js"></script>'); /*==== ANIMATED POPUP ALERTS ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.purr.js"></script>'); /*==== PURR Sticky NOTES ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.simplemodal.js"></script>'); /*==== MODAL BOX ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload_custom.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.gears.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.silverlight.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.flash.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.browserplus.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.html4.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/plupload.html5.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/plupload/jquery.plupload.queue/jquery.plupload.queue.js"></script>'); /*==== PLUPLOAD CUSTOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/file_manager/elfinder.full.js"></script>'); /*==== FILE MANAGER ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/forms-style.js"></script>'); /*==== CHECKBOX AND RADIO ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/slidernav.js"></script>'); /*==== CONTACT LIST ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.fancybox.js"></script>'); /*==== FANCYBOX CHART ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.miniColors.js"></script>'); /*==== COLOR PICKER ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.tipsy.js"></script>'); /*==== TOOLTIP ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/resizable-tables.js"></script>'); /*==== RESIZEABLE TABLE COLOM ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/ui-slider.js"></script>'); /*==== RANGE SLIDER ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/validation/jquery.validationEngine.js"></script>'); /*==== FORMS VALIDATION ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/validation/jquery.validationEngine-en.js"></script>'); /*==== FORMS VALIDATION ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/prefixfree.js"></script>'); /*==== FORMS VALIDATION ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/keyboard/jquery.keyboard.js"></script>'); /*==== KEYBOARD ====*/
  
  // document.writeln('<script type="text/javascript" src="http://freakpixels.com/portfolio/esthetics/scripts/jquery.maskedinput.js"></script>'); /*==== MASKED INPUT FIELDS ====*/
  
  

  
}).call(this);
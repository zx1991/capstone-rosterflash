<?php


$q = $_GET['q'];

include 'includes/dbh.inc.php';

$sql="SELECT * FROM attendances WHERE course_id = '$q' AND attendance = 1 ";
$result = mysqli_query($conn,$sql);

$noa = mysqli_num_rows($result);




echo "$noa,";

$sql="SELECT * FROM attendances WHERE course_id = '".$q."' AND attendance = 0 ";
$result = mysqli_query($conn,$sql);

$non = mysqli_num_rows($result);
echo "$non";





?>
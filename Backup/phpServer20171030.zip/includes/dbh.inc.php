<?php

$dbServername = "174.104.116.122";
$dbUsername = "root";
$dbPassword = "llkwzcapstone";
$dbName = "attendance";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);
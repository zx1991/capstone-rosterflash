<?php
	session_start();
    if (!isset($_SESSION['u_id'])) {
        
        header("Location: ../../../index.php");
			exit();	
    }
?>

<html>
<head>
    <title>Student Roster Tracker</title>
    <link rel="stylesheet" href="../../css/normalize.css" type="text/css">
    <link rel="stylesheet" href="../../css/style.css" type="text/css">
    <link rel="stylesheet" href="../../css/profile.css" type="text/css">
    <script src="../../../js/Chart.min.js"></script>
    
    <meta charset="utf-8">
    
    <link href="../../css/lib/style.css" rel="stylesheet" type="text/css">
    <script src="../../scripts/script.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
    
    
    <link rel="icon" href="../../layui/images/face/65.gif" type="image/gif" >
</head>

<body>
        <header class="site-header">
            <div class="container site-header-inner">
                <!-- logo -->
                <div class="site-logo">ROSTER TRACKER</div>
                <!-- navigation bar -->
                <nav class="nav site-menu">
                    <a href="profile.php" class="nav-link present" id="profileLink">Profile</a>
                    <a href="courseManage/Management.php" class="nav-link" id="coursemLink">Manage Courses</a>
                    <a href="attendance/TotalRatio.php" class="nav-link" id="AttendanceLink">Attendance</a>
                    <!--<a href="#" id=""></a>-->
                </nav>

                <div class="logout">
                    <a href="../../../includes/logout.inc.php" id="logOut">Log out</a>
                </div>
            </div>
        </header>
    
    <div class="site-main">
            <div class="container site-main-inner">
                
                <!-- Content shows here -->
                <div stye="width: 100% !important" class="content">
                    <div class="content-inner">
                       
    <div class="shortable-content">
        <div class="box _50">
            <div class="box-header">
                Full Calendar
            </div>
            <div class="box-content">
                <div id="calendar"></div>
            </div>
        </div>
        <!--CALENDAR ENDS HERE-->
        <div class="box _50">
            <div class="box-header">
                Chatting Layout
                <i class="icon-remove-sign close" title="Close"></i>
                <i class="icon-minus-sign minimize" title="Minimize/Maximize"></i>
            </div>
            <div class="box-content  padd-10">
                <ul class="messages">
       
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
     
                    <li>
                        <input type="text" class="_75" placeholder="Message to the teacher" />
                        <div class="float_r">
                            <input type="reset" class="grey" />
                            <input type="submit" value="Send" />
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <!--MESSAGES ENDS HERE-->
        <div class="box _100">
            <div class="box-header">
                List of students
                <i class="icon-remove-sign close" title="Close"></i>
                <i class="icon-minus-sign minimize" title="Minimize/Maximize"></i>
            </div>
            <div class="box-content">
                <table cellpadding="0" cellspacing="0" border="0" class="dTable" id="dynamic">
                    <thead>
                        <tr>
                            <th>Student ID<span class="sorting" style="display: block;"></span></th>
                            <th>Name</th>
                            <th>course name</th>
                            <th>Attendence information</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>810123124</td>
                            <td>Ann</td>
                            <td>Capstone</td>
                            <td class="center">5</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>Gecko</td>
                            <td>Camino 1.0</td>
                            <td>OSX.2+</td>
                            <td class="center">1.8</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                           <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>810123123</td>
                            <td>Emma Worson</td>
                            <td>Capstone</td>
                            <td class="center">4</td>
                        </tr>
                        <tr>
                            <td>7654324</td>
                            <td>Miaomiao</td>
                            <td>network</td>
                            <td class="center">-</td>
                        </tr>
                        <tr class="gradeU">
                            <td>Other Students</td>
                            <td>All others</td>
                            <td>-</td>
                            <td class="center">-</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
                    
                c
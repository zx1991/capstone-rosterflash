<?php
	include_once 'header.php';
?>


<section class="main-container">
	<div class="main-wrapper">
		<h2></h2>
<?php
	include_once 'navigation.php';
?>
       
		<?php
			if (isset($_SESSION['u_id'])) {
				
			}
		?>
	</div>
    
   
    
</section>



<?php

    
    include 'includes/dbh.inc.php';

    $sql = "SELECT * FROM courses WHERE user_name= '".$_SESSION['u_id']."'";
    $myresult = mysqli_query($conn, $sql);
    $courseInfo = array();
    while ($row_user = mysqli_fetch_assoc($myresult)){
        $userInfo[]=$row_user;
    }
    
?>

<select name="per1" id="per1" onchange="showChart(this.value)">
  <option>Courses</option>
  <?php
    foreach($userInfo as $user) { ?>
      <option value="<?= $user['course_id'] ?>"><?= $user['course_name'] ?></option>
  <?php
    } ?>
</select> 

<canvas id="myChart" ></canvas>
  
	
<div id="txtHint"></div>

<script type="text/javascript">
    var NumberofAttendance = 0;
    var NumberofAbsence = 0;
    
    
   var ctx ;
    var myChart;
    var config;
    
    window.onload = function() {
        
       
        ctx = document.getElementById("myChart").getContext('2d');
        
        
        
                    
                                          
                                          config = {
  type: 'line',
  data: {
    labels: [],
    datasets: [{ 
        data: [],
        label: "",
        borderColor: "#3e95cd",
        fill: false
      }
    ]
  },
};
   myChart = new Chart(ctx, config);
    };
    
   
    
 function showChart(str) {
     
	if (str == "") {
        
        return;} 
     else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var response = JSON.parse(this.responseText);
                var newData =[] ;
                var newlables = [];
                
                   
                
                for(var i =0; i< response.length; i++){
                    
                    newlables.push(response[i].date);
                   
                    newData.push(parseInt(response[i].Occurences));
                    
                    
                }
                
                config = {
  type: 'line',
  data: {
    labels: newlables,
    datasets: [{ 
        data:   newData,
        label: "Attentance by date",
        borderColor: "#3e95cd",
        fill: false
      }
    ]
  },
    options:{
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
};
                
                //myChart.data.labels = newlables;
               // window.alert(response.length);
                //myChart.data.datasets[0].data = newdata;
               // window.alert(response.length);
                myChart.destroy();
                myChart = new Chart(ctx, config);
                
                
                
             
  
            }
        }
        xmlhttp.open("GET", "getNumberBydate.php?q="+str,true);
        xmlhttp.send();
         
        
}
};
  
 

	</script>
	


<?php
	include_once 'footer.php';
?>
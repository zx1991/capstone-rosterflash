<?php


$q = $_GET['q'];

include 'includes/dbh.inc.php';

$sql="SELECT * FROM attendances WHERE course_id = '$q' ORDER BY last_name, student_id, date";
$result = mysqli_query($conn,$sql);

print("[");
	$start = true;
	while($row = mysqli_fetch_array($result)){
		if($start){
			$start = false;
		}else{
			print(",");
		}
		print('{"last_name":"'.$row['last_name'].'",');
		print('"first_name":"'.$row['first_name'].'",');
		print('"student_id":"'.$row['student_id'].'",');
		print('"date":"'.$row['date'].'",');
		print('"time":"'.$row['time'].'",');
		print('"attendance":"'.$row['attendance'].'"');
		print('}');
	}
	print("]");



?>
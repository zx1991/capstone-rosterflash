
<div id="mySidenav" class="sidenav">
  <a href="#" id="Profile">Profile</a>
  <a href="info.php" id="Rate">AttendanceRate</a>
  <a href="ReportBydate.php" id="Date">Attendancebydate</a>
  <a href="StudentTable.php" id="table">DetailedTable</a>
</div>